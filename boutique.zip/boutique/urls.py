from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # Vue d'accueil qui redirige vers dashboard.html
    path('products/search/', views.product_search, name='product_search'),
    
] 