from django import forms
from .models import Product, Category, Sale, SaleItem

class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['name', 'description']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'category', 'description', 'price', 'stock_quantity']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }

class SaleItemForm(forms.ModelForm):
    class Meta:
        model = SaleItem
        fields = ['product', 'quantity']
        widgets = {
            'product': forms.Select(attrs={'class': 'form-select'}),
            'quantity': forms.NumberInput(attrs={'min': 1}),
        }

    def clean(self):
        cleaned_data = super().clean()
        product = cleaned_data.get('product')
        quantity = cleaned_data.get('quantity')
        
        if product and quantity:
            if quantity > product.stock_quantity:
                raise forms.ValidationError(f"Stock insuffisant. Disponible: {product.stock_quantity}")
        return cleaned_data
    

class SaleForm(forms.ModelForm):
    class Meta:
        model = Sale
        fields = ['payment_method']
        widgets = {
            'payment_method': forms.Select(attrs={'class': 'form-select'}),
        }

class SaleItemFormSet(forms.BaseModelFormSet):
    def clean(self):
        super().clean()
        if any(self.errors):
            return
        
        products = []
        for form in self.forms:
            if form.cleaned_data and not form.cleaned_data.get('DELETE', False):
                product = form.cleaned_data['product']
                quantity = form.cleaned_data['quantity']
                
                if product in products:
                    raise forms.ValidationError(
                        "Vous ne pouvez pas ajouter le même produit plusieurs fois."
                    )
                products.append(product)
                
                if quantity > product.stock_quantity:
                    raise forms.ValidationError(
                        f"Stock insuffisant pour {product.name}. Disponible: {product.stock_quantity}"
                    )