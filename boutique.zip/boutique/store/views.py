from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from .models import Category, Product, Sale, SaleItem
from django.db.models import Sum, Count, Avg, F, ExpressionWrapper, DecimalField
from django.db.models.functions import TruncDate
from django.utils import timezone
from .forms import ProductForm, CategoryForm, SaleForm, SaleItemForm, SaleItemFormSet
from django.urls import reverse
from django.forms import modelformset_factory
from datetime import timedelta
from django.http import JsonResponse
from django.contrib.auth import authenticate, login

def dashboard(request):
    # Statistiques Generales
    total_products = Product.objects.filter(is_active=True).count()
    total_sales = Sale.objects.count()
    low_stock_products = Product.objects.filter(stock_quantity__lte=5, is_active=True).count()
    
    # Ventes du jour
    today = timezone.now().date()
    today_sales = Sale.objects.filter(created_at__date=today).aggregate(
        total=Sum('total_amount'),
        count=Count('id')
    )

    
    # Ventes des 7 derniers jours

    # last_week = today - timedelta(days=7)

    # daily_sales = Sale.objects.filter(

    #     created_at__date__gte=last_week

    # ).annotate(

    #     date=TruncDate('created_at')

    # ).values('date').annotate(

    #     total=Sum('total_amount'),

    #     count=Count('id')

    # ).order_by('date')

    

    # Top 5 des produits les plus vendus

    top_products = Product.objects.annotate(

        total_sold=Sum('saleitem__quantity'),

        revenue=Sum(

            ExpressionWrapper(

                F('saleitem__quantity') * F('saleitem__unit_price'),

                output_field=DecimalField()

            )

        )

    ).filter(total_sold__isnull=False).order_by('-total_sold')[:5]

    

    # Répartition des modes de paiement

    payment_methods = Sale.objects.values('payment_method').annotate(

        count=Count('id'),

        total=Sum('total_amount')

    )
    # #Verification des données
    # print("Daily Sales:", daily_sales)
    # print("Payment Methods:", payment_methods)
    
    context = {
        'total_products': total_products,
        'total_sales': total_sales,
        'low_stock_products': low_stock_products,
        'today_sales': today_sales,
        
        # 'daily_sales': daily_sales,

        'top_products': top_products,

        'payment_methods': payment_methods,

    }
    return render(request, 'store/dashboard.html', context)

def product_list(request):
    products = Product.objects.filter(is_active=True)
    return render(request, 'store/product_list.html', {'products': products})

def product_search(request):
    query = request.GET.get('q', '')
    products = Product.objects.filter(name__icontains=query, is_active=True)
    return render(request, 'store/product_search.html', {'products': products, 'query': query})


def product_create(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Produit ajouté avec succès.')
            return redirect('product_list')
    else:
        form = ProductForm()
    
    return render(request, 'store/product_form.html', {
        'form': form,
        'title': 'Nouveau Produit'
    })

def product_edit(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        if form.is_valid():
            form.save()
            messages.success(request, 'Produit mis à jour avec succès.')
            return redirect('product_list')
    else:
        form = ProductForm(instance=product)
    
    return render(request, 'store/product_form.html', {
        'form': form,
        'title': 'Modifier Produit'
    })

def product_delete(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        product.is_active = False
        product.save()
        messages.success(request, 'Produit supprimé avec succès.')
    return redirect('product_list') 



def sale_new(request):
    SaleItemFormSet = modelformset_factory(
        SaleItem, 
        form=SaleItemForm,
        extra=1,
        can_delete=True
    )
    
    if request.method == 'POST':
        sale_form = SaleForm(request.POST)
        formset = SaleItemFormSet(request.POST, queryset=SaleItem.objects.none())
        
        if sale_form.is_valid() and formset.is_valid():
            sale = sale_form.save(commit=False)
            total_amount = 0
            
            # Calcule du montant total
            for form in formset:
                if form.cleaned_data and not form.cleaned_data.get('DELETE', False):
                    product = form.cleaned_data['product']
                    quantity = form.cleaned_data['quantity']
                    if product and quantity:  # Vérifie que le produit et la quantité sont valides
                        total_amount += product.price * quantity
            
            if total_amount > 0:  # Assure que le montant total est positif
                sale.total_amount = total_amount
                sale.save()
                
                # Sauvegarde des articles et mise à jour du stock
                items = formset.save(commit=False)
                for item in items:
                    item.sale = sale
                    item.unit_price = item.product.price  
                    item.product.stock_quantity -= item.quantity
                    item.product.save()
                    item.save()
                
                messages.success(request, 'Vente enregistrée avec succès.')
                return redirect('sale_detail', pk=sale.pk)
            else:
                messages.error(request, 'Le montant total doit être supérieur à zéro.')
        else:
            messages.error(request, 'Veuillez corriger les erreurs dans le formulaire.')
    else:
        sale_form = SaleForm()
        formset = SaleItemFormSet(queryset=SaleItem.objects.none())
    
    return render(request, 'store/sale_form.html', {
        'sale_form': sale_form,
        'formset': formset,
    })

def get_product_price(request, product_id):
    try:
        product = Product.objects.get(id=product_id)
        return JsonResponse({'price': str(product.price)})
    except Product.DoesNotExist:
        return JsonResponse({'error': 'Produit non trouvé'}, status=404)

def sale_detail(request, pk):
    sale = get_object_or_404(Sale, pk=pk)
    return render(request, 'store/sale_detail.html', {'sale': sale})

#  Vue pour afficher la liste des ventes
    
#     :param request: requête HTTP
#     :return: page HTML avec la liste des ventes
def sale_list(request):    
    sales = Sale.objects.all().order_by('-created_at')
    return render(request, 'store/sale_list.html', {'sales': sales}) 

def home(request):
    return render(request, 'store/dashboard.html')  

def index(request):
    products = Product.objects.filter(is_active=True)  # Récupérer les produits actifs
    categories = Category.objects.filter(is_active=True)  # Récupérer les catégories actives
    return render(request, 'store/index.html', {'products': products, 'categories': categories})  

def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    return render(request, 'store/product_detail.html', {'product': product})  

def products_by_category(request, category_id):
    products = Product.objects.filter(category_id=category_id, is_active=True)  # Récupérer les produits actifs de la catégorie
    category = get_object_or_404(Category, id=category_id)  # Récupérer la catégorie
    return render(request, 'store/product_list.html', {'products': products, 'category': category})  

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('index')  # Redirigez vers la page d'accueil 
    return render(request, 'store/login.html')  # Affichez le formulaire de connexion
