from django.urls import path
from . import views
from .views import get_product_price, home, index

urlpatterns = [
    path('', home, name='home'),
    path('index/', index, name='index'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('products/', views.product_list, name='product_list'),
    path('products/search/', views.product_search, name='product_search'),
    path('products/create/', views.product_create, name='product_create'),
    path('products/<int:pk>/edit/', views.product_edit, name='product_edit'),
    path('products/<int:pk>/delete/', views.product_delete, name='product_delete'),
    path('products/category/<int:category_id>/', views.products_by_category, name='products_by_category'),
    path('products/<int:pk>/', views.product_detail, name='product_detail'),
    path('sales/', views.sale_list, name='sale_list'),
    path('sales/new/', views.sale_new, name='sale_new'),
    path('sales/<int:pk>/', views.sale_detail, name='sale_detail'),
    path('get-product-price/<int:product_id>/', get_product_price, name='get_product_price'),
    path('login/', views.login_view, name='login'),
]