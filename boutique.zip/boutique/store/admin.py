from django.contrib import admin
from store.models import Category, Product, Sale, SaleItem
from django.contrib.admin import AdminSite

""" 
class BoutiqueAdminSite(AdminSite):
    site_header = 'Administration de la Boutique'
    site_title = 'Boutique Admin'
    index_title = 'Tableau de bord d\'administration'


#instance admin_site
admin_site = BoutiqueAdminSite(name='boutique_admin') """

# Enregistrement des modèles

#if admin_site is not None:
    #admin_site.register(Category)
    #@admin.register(Category)

class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'is_active', 'created_at', 'updated_at')
    list_filter = ('is_active',)
    search_fields = ('name',)
    ordering = ('name',)
admin.site.register(Category)


class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'price', 'stock_quantity', 'is_active')
    list_filter = ('category', 'is_active')
    search_fields = ('name', 'description')
    ordering = ('name',)
    list_editable = ('price', 'stock_quantity')
admin.site.register(Product, ProductAdmin)

class SaleItemInline(admin.TabularInline):
    model = SaleItem
    fk_name = 'sale'
    #extra = 1 
    #readonly_fields = ('unit_price',)
#admin.site.register(SaleItem, SaleItemInline)

#@admin_site.register(Sale)
class SaleAdmin(admin.ModelAdmin):
    list_display = ('id', 'created_at', 'payment_method', 'get_total_amount')
    list_filter = ('payment_method', 'created_at')
    # readonly_fields = ('get_total_amount',)
    inlines = [SaleItemInline]
    date_hierarchy = 'created_at'
admin.site.register(Sale, SaleAdmin)

def has_add_permission(self, request):
        # Désactiver la création de ventes depuis l'admin
        return False