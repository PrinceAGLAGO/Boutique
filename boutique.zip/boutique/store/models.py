from django.db import models
from django.core.validators import MinValueValidator
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.models import User


class Category(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name_plural = "Categories"

    def __str__(self):
        
        return self.name
    
    def get_products_count(self):

        
        return self.product_set.count()

    get_products_count.short_description = 'Nombre de produits'

class Product(models.Model):
    name = models.CharField(max_length=255)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    stock_quantity = models.IntegerField()
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name
    
    def get_sales_count(self):

        return self.saleitem_set.count()

    get_sales_count.short_description = 'Nombre de ventes'



    def get_total_sales(self):

        return sum(item.quantity * item.unit_price for item in self.saleitem_set.all())

    get_total_sales.short_description = 'Total des ventes'

    def clean(self):

        if self.price is not None and self.price < 0:

            raise ValidationError({

                'price': _('Le prix ne peut pas être négatif.')

            })

        if self.stock_quantity is not None and self.stock_quantity < 0:

            raise ValidationError({

                'stock_quantity': _('La quantité en stock ne peut pas être négative.')

            })




class Sale(models.Model):
    class PaymentMethod(models.TextChoices): 
         CASH = 'CASH', 'Cash'
         TMONEY = 'TMONEY', 'TMoney'
         FLOOZ = 'FLOOZ', 'Flooz'
    
    payment_method = models.CharField(
        max_length=10,
        choices=PaymentMethod,
        default='CASH',
        verbose_name='Moyen de paiement'
    )
    total_amount = models.DecimalField(max_digits=10, decimal_places=2,default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Vente #{self.id} - {self.created_at.strftime('%Y-%m-%d %H:%M')}"
    
    def get_total_amount(self):
        return sum(item.get_total() for item in self.items.all())
    
    
    def get_items_count(self):

        return self.items.count()

    get_items_count.short_description = 'Nombre d\'articles'



    class Meta:

        ordering = ['-created_at']

        verbose_name = 'Vente'

        verbose_name_plural = 'Ventes'

class SaleItem(models.Model):
    sale = models.ForeignKey('Sale', related_name='items', on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    
    def __str__(self):
        return f"{self.product.name} ({self.quantity})"
    
    def get_total(self):

        return self.quantity * self.unit_price

    get_total.short_description = 'Total'

    def clean(self):

        if self.quantity <= 0:

            raise ValidationError({

                'quantity': _('La quantité doit être supérieure à zéro.')

            })

        if self.unit_price < 0:

            raise ValidationError({

                'unit_price': _('Le prix unitaire ne peut pas être négatif.')

            })




    class Meta:

        verbose_name = 'Article de vente'

        verbose_name_plural = 'Articles de vente' 
